document.addEventListener('DOMContentLoaded', function() {
    const menuToggle = document.getElementById('menu-toggle');
    const navbarContainer = document.getElementById('navbar-container');

    menuToggle.addEventListener('click', function() {
        navbarContainer.classList.toggle('show');
    });
});
